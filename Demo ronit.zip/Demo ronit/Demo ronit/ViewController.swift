//
//  ViewController.swift
//  Demo ronit
//
//  Created by Ronit on 9/4/20.
//  Copyright © 2020 Ronit. All rights reserved.
//

import UIKit

class ViewController: UIViewController,UITableViewDelegate,UITableViewDataSource {

       @IBOutlet weak var Tabllist: UITableView!
        var indexpathList : Int = 0
        var totalRow = 100
        var changeText = [Bool]()
        
override func viewDidLoad() {
    super.viewDidLoad()
    for i  in 0 ..<  totalRow
    {
        changeText.insert(false, at: i)
    }
    self.firstChange()
            // Do any additional setup after loading the view.
}
func firstChange()
{
    let seconds = 1.0
    DispatchQueue.main.asyncAfter(deadline: .now() + seconds) {
        // Put your code which should be executed with a delay here
        self.indexpathList += 10
        for i  in 0 ..<  self.indexpathList
        {
            self.changeText.remove(at: i)
            self.changeText.insert(true, at: i)
        }
        self.Tabllist.reloadData()
    }
    
}
func numberOfSections(in tableView: UITableView) -> Int {
    return 1
}
func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
    
    return totalRow
}
func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
    let cell:UITableViewCell = (tableView.dequeueReusableCell(withIdentifier: "Cell") as UITableViewCell?)!
   cell.textLabel?.text = "Hello World"
   
    if  changeText[indexPath.row] == true
    {
        cell.textLabel?.font = .boldSystemFont(ofSize: 19)
    }
    else
    {
        cell.textLabel?.font = .italicSystemFont(ofSize: 17)
    }
    return cell
}
func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat
{
    if ( UIDevice.current.model.range(of: "iPad") != nil)
    {
        return 70.0

    }
    else
    {
        return 40.0

    }
}

func scrollViewDidEndDragging(_ scrollView: UIScrollView, willDecelerate decelerate: Bool)
{
//                let offsetY = scrollView.contentOffset.y
//                let contentHeight = scrollView.contentSize.height
//
//                if offsetY > contentHeight - scrollView.frame.size.height {
            
            indexpathList += 10
            if indexpathList > 100
            {
                
            }
            else
            {
                for i  in 0 ..<  indexpathList
                {
                    changeText.remove(at: i)
                    changeText.insert(true, at: i)
                }
                Tabllist.reloadData()
    //            sleep(2)
            }
           
    //            // working
    //            DispatchQueue.main.async
    //                {
    //                    print("sleep for 2 seconds.")
    //                    // your code here
    //                    sleep(2)
    //                    self.Tabllist.beginUpdates()
    //                    let indexPath = NSIndexPath.init(row:  self.indexpathList, section: 0)
    //                    self.Tabllist.reloadRows(at: [indexPath as IndexPath], with: .none)
    //                    self.Tabllist.endUpdates()
    //                    for i  in 0 ..<  self.indexpathList
    //                    {
    //                        self.Tabllist.reloadRows(at: [self.indexpathList as! IndexPath], with: .fade)
    //                    }
    //                }
    //              break
    //        }
       }

    }

extension UITableView
{
        
        // Default delay time = 0.5 seconds
        // Pass delay time interval, as a parameter argument
        func reloadDataAfterDelay(delayTime: TimeInterval = 2.0) -> Void {
            self.perform(#selector(self.reloadData), with: nil, afterDelay: delayTime)
        }
        
}
